<?php
// Database connection
$db = new mysqli('localhost', 'root', '', 'pass_enc_dcry');
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Get user input
$username = $_POST['username'];
$password = $_POST['password'];

// Retrieve the user's stored password hash from the database
$query = "SELECT password FROM users WHERE username = ?";
$stmt = $db->prepare($query);
$stmt->bind_param('s', $username);
$stmt->execute();
$stmt->bind_result($hashedPassword);
$stmt->fetch();

// Verify the entered password
if (password_verify($password, $hashedPassword)) {
    // Password is correct
    echo "Login successful!";
} else {
    // Password is incorrect
    echo "Login failed!";
}

// Close the database connection
$stmt->close();
$db->close();
?>
