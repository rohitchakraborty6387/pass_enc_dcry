<?php
// Database connection
$db = new mysqli('localhost', 'root', '', 'pass_enc_dcry');
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

if(isset($_POST['submit'])){


// Get user input
$username = $_POST['username'];
$password = $_POST['password'];

// Hash the password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Check if the username is already taken
$checkQuery = "SELECT id FROM users WHERE username = ?";
$checkStmt = $db->prepare($checkQuery);
$checkStmt->bind_param('s', $username);
$checkStmt->execute();
$checkStmt->store_result();

if ($checkStmt->num_rows > 0) {
    echo "Username already taken. Please choose another one.";
} else {
    // Insert the new user into the database
    $insertQuery = "INSERT INTO users (username, password) VALUES (?, ?)";
    $insertStmt = $db->prepare($insertQuery);
    $insertStmt->bind_param('ss', $username, $hashedPassword);

    if ($insertStmt->execute()) {
        echo "Registration successful!";
    } else {
        echo "Registration failed. Please try again.";
    }
}

// Close the database connection
$checkStmt->close();
$insertStmt->close();
$db->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="registration-container">
        <form action="register.php" method="post">
            <label for="username">Username</label>
            <input type="text" name="username" id="username" required>
            <label for="password">Password</label>
            <input type="password" name="password" id="password" required>
            <input name="submit" type="submit" value="Register">
        </form>
    </div>
</body>
</html>
